const BASE_URL = 'http://localhost:8000'
let mode = 'CREATE' //default mode
let selectedID = ''

window.onload = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id')
    console.log('id', id);
    if (id) {
        mode = 'EDIT'
        selectedID = id

        //1. ดึง user ที่ต้องการแก้ไข
         try {
            const response = await axios.get(`${BASE_URL}/users/${id}`);
            console.log('data', response.data);
            const user = response.data;
            
            //2. นำข้อมูล user ที่ดึงมา ใส่ใน input ที่มี

            let firstNameDOM = document.querySelector("input[name=firstname]")
            let lastNameDOM = document.querySelector("input[name=lastname]")
            let ageDOM = document.querySelector("input[name=age]")
            let descriptionDOM = document.querySelector("textarea[name='description']")

            firstNameDOM.value = user.firstname
            lastNameDOM.value = user.lastname
            ageDOM.value = user.age
            descriptionDOM.value = user.description

            
            let genderDOMs = document.querySelectorAll("input[name=gender]")
            let interestDOMs = document.querySelectorAll("input[name=interest]")

            for (let i =0; i < genderDOMs.length; i++) {
                if (genderDOMs[i].value == user.gender) {
                    genderDOMs[i].checked = true
                }
            }
            
            for (let i =0; i < interestDOMs.length; i++) {
                if (user.interests.includes(interestDOMs[i].value)) {
                    interestDOMs[i].checked = true
                }
            }

         } catch (error) { 
            console.log('error', error);
         }
        
    }
}

const validateData = (userData) => {
    let errors = [];
    if (!userData.firstName) {
        errors.push('กรุณากรอกชื่อ');
    }
    if (!userData.lastName) {
        errors.push('กรุณากรอกนามสกุล');
    }
    if (!userData.age) {
        errors.push('กรุณากรอกอายุ');
    }
    if (!userData.gender) {
        errors.push('กรุณาเลือกเพศ');
    }
    if (!userData.interest || userData.interest.length === 0) {
        errors.push('กรุณาเลือกงานอดิเรก');
    }
    return errors;
};

const submitData = async () => {
    let firstNameDOM = document.querySelector("input[name=firstname]");
    let lastNameDOM = document.querySelector("input[name=lastname]");
    let ageDOM = document.querySelector("input[name=age]");
    let genderDOM = document.querySelector("input[name=gender]:checked");
    let interestDOMs = document.querySelectorAll("input[name=interest]:checked");
    let descriptionDOM = document.querySelector("textarea[name='description']");
    let messageDOM = document.getElementById('message');

    let interest = [];
    for (let i = 0; i < interestDOMs.length; i++) {
        interest.push(interestDOMs[i].value);
    }

    let userData = {
        firstName: firstNameDOM.value.trim(),
        lastName: lastNameDOM.value.trim(),
        age: ageDOM.value.trim(),
        gender: genderDOM ? genderDOM.value : '',
        interest: interest.length > 0 ? interest : null,
        description: descriptionDOM.value.trim()
    };

    // 🔴 เรียก validateData ก่อนส่ง
    const errors = validateData(userData);
    if (errors.length > 0) {
        let htmlData = '<div><ul>';
        for (let i = 0; i < errors.length; i++) {
            htmlData += '<li>' + errors[i] + '</li>';
        }
        htmlData += '</ul></div>';
        messageDOM.innerHTML = htmlData;
        messageDOM.className = 'message danger';
        return; // ❗ หยุดการ submit ถ้ามี error
    }

    // ดำเนินการ submit ตามปกติ (axios)
    try {
        let message = 'บันทึกข้อมูลเรียบร้อย';
        if (mode == 'CREATE') {
            await axios.post(`${BASE_URL}/users`, userData);
        } else {
            await axios.put(`${BASE_URL}/users/${selectedID}`, userData);
            message = 'แก้ไขข้อมูลเรียบร้อย';
        }

        messageDOM.innerText = message;
        messageDOM.className = 'message success';
    } catch (error) {
        console.log('error', error);
        let htmlData = '<div><ul>';
        if (error.response?.data?.errors) {
            for (let i = 0; i < error.response.data.errors.length; i++) {
                htmlData += '<li>' + error.response.data.errors[i] + '</li>';
            }
        } else {
            htmlData += '<li>' + error.message + '</li>';
        }
        htmlData += '</ul></div>';
        messageDOM.innerHTML = htmlData;
        messageDOM.className = 'message danger';
    }
};
